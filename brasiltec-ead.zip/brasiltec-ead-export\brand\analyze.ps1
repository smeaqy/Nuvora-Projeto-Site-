Add-Type -AssemblyName System.Drawing

$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$files = Get-ChildItem $dir -Filter *.jpg | Sort-Object Name

function Get-Palette([string]$path, [int]$step = 4) {
  $bmp = [System.Drawing.Bitmap]::FromFile($path)
  $counts = @{}
  for ($y = 0; $y -lt $bmp.Height; $y += $step) {
    for ($x = 0; $x -lt $bmp.Width; $x += $step) {
      $c = $bmp.GetPixel($x, $y)
      $r = [int]([math]::Floor($c.R / 16) * 16)
      $g = [int]([math]::Floor($c.G / 16) * 16)
      $b = [int]([math]::Floor($c.B / 16) * 16)
      $key = ('{0:x2}{1:x2}{2:x2}' -f $r, $g, $b)
      if ($counts.ContainsKey($key)) { $counts[$key] = $counts[$key] + 1 }
      else { $counts[$key] = 1 }
    }
  }
  $bmp.Dispose()
  $total = 0
  foreach ($v in $counts.Values) { $total += $v }
  $top = $counts.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 14
  Write-Output "### $(Split-Path -Leaf $path)  ($($total) samples)"
  foreach ($e in $top) {
    $pct = [math]::Round(($e.Value / $total) * 100, 1)
    Write-Output ("  #{0}  {1}%" -f $e.Key, $pct)
  }
  Write-Output ""
}

function Get-Ascii([string]$path, [int]$w = 36) {
  $bmp = [System.Drawing.Bitmap]::FromFile($path)
  $h = [int]($bmp.Height / $bmp.Width * $w * 0.5)
  if ($h -lt 1) { $h = 1 }
  Write-Output "### ASCII $(Split-Path -Leaf $path) ${w}x${h}"
  for ($row = 0; $row -lt $h; $row++) {
    $line = ''
    for ($col = 0; $col -lt $w; $col++) {
      $x = [int]($col / $w * $bmp.Width)
      $y = [int]($row / $h * $bmp.Height)
      $c = $bmp.GetPixel($x, $y)
      $lum = 0.2126 * $c.R + 0.7152 * $c.G + 0.0722 * $c.B
      if ($lum -gt 224) { $line += ' ' }
      elseif ($lum -gt 192) { $line += '.' }
      elseif ($lum -gt 160) { $line += ':' }
      elseif ($lum -gt 128) { $line += '*' }
      elseif ($lum -gt 96) { $line += 'o' }
      elseif ($lum -gt 64) { $line += 'O' }
      elseif ($lum -gt 32) { $line += '#' }
      else { $line += '@' }
    }
    Write-Output $line
  }
  $bmp.Dispose()
  Write-Output ""
}

function Get-Center([string]$path) {
  $bmp = [System.Drawing.Bitmap]::FromFile($path)
  Write-Output "### Center $(Split-Path -Leaf $path) $($bmp.Width)x$($bmp.Height)"
  $samples = @()
  foreach ($fx in @(0.15,0.3,0.5,0.7,0.85)) {
    foreach ($fy in @(0.2,0.4,0.6,0.8,0.5)) {
      $c = $bmp.GetPixel([int]($fx * ($bmp.Width - 1)), [int]($fy * ($bmp.Height - 1)))
      $samples += ('{0:x2}{1:x2}{2:x2}' -f $c.R, $c.G, $c.B)
    }
  }
  Write-Output ("  " + ($samples -join ' '))
  $bmp.Dispose()
  Write-Output ""
}

foreach ($f in $files) {
  Get-Palette $f.FullName 4
}
Get-Ascii (Join-Path $dir 'profile.jpg') 36
Get-Center (Join-Path $dir 'profile.jpg')
