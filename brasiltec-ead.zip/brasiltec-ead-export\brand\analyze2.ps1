Add-Type -AssemblyName System.Drawing

$dir = Split-Path -Parent $MyInvocation.MyCommand.Path

function Get-CropAscii([string]$path, [string]$name, [int]$w = 46) {
  $bmp = [System.Drawing.Bitmap]::FromFile($path)
  $minX = $bmp.Width; $minY = $bmp.Height; $maxX = 0; $maxY = 0
  for ($y = 0; $y -lt $bmp.Height; $y++) {
    for ($x = 0; $x -lt $bmp.Width; $x++) {
      $c = $bmp.GetPixel($x,$y)
      $lum = 0.2126*$c.R + 0.7152*$c.G + 0.0722*$c.B
      if ($lum -lt 180) {
        if ($x -lt $minX) { $minX = $x }; if ($x -gt $maxX) { $maxX = $x }
        if ($y -lt $minY) { $minY = $y }; if ($y -gt $maxY) { $maxY = $y }
      }
    }
  }
  Write-Output "### $name bbox $minX,$minY - $maxX,$maxY"
  if ($maxX -le $minX) { return }
  $cw = $maxX - $minX + 1; $ch = $maxY - $minY + 1
  $h = [int]($ch / $cw * $w * 0.55); if ($h -lt 1) { $h = 1 }
  for ($row = 0; $row -lt $h; $row++) {
    $line = ''
    for ($col = 0; $col -lt $w; $col++) {
      $x = $minX + [int]($col / $w * $cw)
      $y = $minY + [int]($row / $h * $ch)
      $c = $bmp.GetPixel($x,$y)
      $lum = 0.2126*$c.R + 0.7152*$c.G + 0.0722*$c.B
      if ($lum -gt 235) { $line += ' ' }
      elseif ($lum -gt 200) { $line += '.' }
      elseif ($lum -gt 160) { $line += ':' }
      elseif ($lum -gt 110) { $line += '*' }
      elseif ($lum -gt 60) { $line += 'O' }
      else { $line += '#' }
    }
    Write-Output $line
  }
  $bmp.Dispose()
  Write-Output ''
}

function Get-Saturated([string]$path) {
  $bmp = [System.Drawing.Bitmap]::FromFile($path)
  $counts = @{}
  for ($y = 0; $y -lt $bmp.Height; $y += 2) {
    for ($x = 0; $x -lt $bmp.Width; $x += 2) {
      $c = $bmp.GetPixel($x,$y)
      $max = [math]::Max($c.R,[math]::Max($c.G,$c.B)); $min = [math]::Min($c.R,[math]::Min($c.G,$c.B))
      $sat = if ($max -eq 0) { 0 } else { ($max-$min)/$max }
      if ($sat -gt 0.28 -and $max -gt 40) {
        $r=[int]([math]::Floor($c.R/8)*8); $g=[int]([math]::Floor($c.G/8)*8); $b=[int]([math]::Floor($c.B/8)*8)
        $key = ('{0:x2}{1:x2}{2:x2}' -f $r,$g,$b)
        if ($counts.ContainsKey($key)) { $counts[$key]++ } else { $counts[$key]=1 }
      }
    }
  }
  $bmp.Dispose()
  Write-Output "### Saturated $(Split-Path -Leaf $path)"
  $total = 0; foreach ($v in $counts.Values) { $total += $v }
  $counts.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 18 | ForEach-Object {
    Write-Output ("  #{0}  {1}%" -f $_.Key, [math]::Round(($_.Value/$total)*100,1))
  }
  Write-Output ''
}

Get-CropAscii (Join-Path $dir 'profile.jpg') 'profile' 54
foreach ($f in (Get-ChildItem $dir -Filter 'post*.jpg')) { Get-Saturated $f.FullName }
